import os
from csv import DictReader
from datetime import datetime
from pytz import UTC

if __name__ == "__main__":
    DATETIME_FORMAT = '%m/%d/%Y %H:%M'
    for row in DictReader(open('/home/vision-thangld45/Desktop/learning-django-2825501/wisdompets/pet_data.csv')):
        # pet = Pet()
        # pet.name = row['Pet']
        # pet.submitter = row['Submitter']
        # pet.species = row['Species']
        # pet.breed = row['Breed']
        # pet.description = row['Pet Description']
        # pet.sex = row['Sex']
        # pet.age = row['Age']
        # raw_submission_date = row['submission date']
        # print("----------------------------------------------------------------------")
        # print(raw_submission_date)
        # print("----------------------------------------------------------------------")
        # submission_date = UTC.localize(
        #     datetime.strptime(raw_submission_date, DATETIME_FORMAT))
        # pet.submission_date = submission_date
        raw_submission_date = row['submission date']
        submission_date = UTC.localize(
        datetime.strptime(raw_submission_date, DATETIME_FORMAT))
        print(submission_date)
